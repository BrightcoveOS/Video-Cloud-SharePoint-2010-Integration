﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BrightcoveSDK.Media
{
	/// <summary>
	/// The Player object is an aggregation of metadata and asset information associated with a player
	/// </summary>
	public class BCPlayer
	{
	}
}
