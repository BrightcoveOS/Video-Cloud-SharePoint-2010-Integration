Set-location c:\Brightcove
#.\Uninstall-Solution.ps1 -path .\BrightcoveVideoCloudIntegration.wsp -webapp "http://MySharePointSite/"
.\Install-Solution.ps1 -path .\BrightcoveVideoCloudIntegration.wsp -webapp "http://MySharePointSite/"
