param (
	[string] $path=$(throw "Requires path to .wsp to install"),
	$webApplication=$null,
	[switch] $allWebApplications=$false
)

#check for SP addin, stop if not active
[void](get-pssnapin Microsoft.SharePoint.PowerShell -ea stop)

$sleepseconds = 15

$path = Resolve-path $path
$identity = split-path -leaf $path

$webAppSuffix = ""
$urlSuffix = ""
if ($allWebApplications) {
	$webAppSuffix = " -AllWebApplications"
} elseif ($null -ne $webApplication) {
	$webAppSuffix = " -WebApplication $($webApplication.ToString())"
	$urlSuffix = " -Url $($webApplication.ToString())"
}
write-debug $webAppSuffix


$solution = get-SPSolution -Identity $identity -ea Stop
Get-SPFeature | where { $_.SolutionID -eq $solution.ID } | 
	% { Invoke-Expression "Disable-SPFeature -Confirm:`$False -Identity '$($_.DisplayName)' $urlSuffix" }

$installCommand = "Uninstall-SPSolution -Confirm:`$False -Identity $identity -ea Stop"
Invoke-expression "$installCommand$webAppSuffix"
while ($($sln = (Get-SPSolution -Identity $identity -ea SilentlyContinue); $sln.Deployed -or $sln.JobExists)) {
	"Sleeping $sleepseconds seconds on solution uninstall..."
	Start-Sleep $sleepseconds
}

Remove-SPSolution -Confirm:$False -Identity $identity -ea Stop
while ((Get-SPSolution -Identity $identity -ea SilentlyContinue)) {
	"Sleeping $sleepseconds seconds on solution remove..."
	Start-Sleep $sleepseconds
}

""
"Completed $([DateTime]::Now.ToString())"

