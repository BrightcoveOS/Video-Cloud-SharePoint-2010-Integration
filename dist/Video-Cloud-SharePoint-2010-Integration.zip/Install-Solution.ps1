param (
	[string] $path=$(throw "Requires path to .wsp to install"),
	$webApplication=$null,
	[switch] $allWebApplications=$false,
	[switch] $noEnable=$false
)

#check for SP addin, stop if not active
[void](get-pssnapin Microsoft.SharePoint.PowerShell -ea stop)

$sleepseconds = 15

$path = Resolve-path $path
$identity = split-path -leaf $path

Add-SPSolution $path -ea Stop
while (!(Get-SPSolution -Identity $identity -ea SilentlyContinue)) {
	"Sleeping $sleepseconds seconds on solution add..."
	Start-Sleep $sleepseconds
}
$installCommand = "Install-SPSolution -Identity $identity -CASPolicies -GACDeployment -ea Stop"
if ($allWebApplications) {
	$installCommand = $installCommand + " -AllWebApplications"
} elseif ($null -ne $webApplication) {
	$installCommand = $installCommand + " -WebApplication " + $webApplication.ToString()
}
write-debug $installCommand
Invoke-expression $installCommand
while ($($sln = (Get-SPSolution -Identity $identity -ea SilentlyContinue); !($sln.Deployed) -or $sln.JobExists)) {
	"Sleeping $sleepseconds seconds on solution install..."
	Start-Sleep $sleepseconds
}
iisreset /noforce
""
if (!$noEnable) {
if ($null -ne $WebApplication) { 
	$url = $webApplication.ToString() 
} else { 
	$url = "http://$([Environment]::MachineName)" } 
Get-SPFeature | 
	where { $_.SolutionID -eq (Get-SPSolution -id "$identity").ID } | 
	Enable-SPFeature -Url $url
'Features enabled!'
} else {
"Solution installed but features not enabled."
"To enable features:"
""
"Get-SPFeature | where { `$_.SolutionID -eq (Get-SPSolution -id '$identity').ID } |"
"`tEnable-SPFeature -Url http://$([Environment]::MachineName)/..."
}
""
"Completed $([DateTime]::Now.ToString())"
