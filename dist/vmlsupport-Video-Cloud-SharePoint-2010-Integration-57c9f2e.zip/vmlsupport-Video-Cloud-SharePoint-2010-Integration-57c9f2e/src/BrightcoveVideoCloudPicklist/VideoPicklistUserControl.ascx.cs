﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace BrightcoveVideoCloudIntegration.VideoPicklist
{
    public partial class VideoPicklistUserControl : VideoCloudWebPartUserControl
    {
        public override void Deprecated_Page_Load()
        {
        }
    }
}
